<?php get_header();?>
    <main class="container">
        <header class="title"><h1>یافت نشد</h1></header>
        <div class="img-center"><img alt="404" src="<?php echo get_template_directory_uri(); ?>/img/404.gif"></div>
        <p class="text_center"><h3>با عرض پوزش صفحه مورد نظر شما یافت نشد. لطفا از دسته های اصلی سایت و صفحات دیگر دیدن فرمایید.</h3></p>
    </main>
<?php get_footer();?>