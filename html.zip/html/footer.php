		<footer class="footer row">
			<div class="col-xs-12">
				<p>تمامي حقوق طراحی و ثبت برای این وب سایت محفوظ مي باشد.</p>
				<a href="<?php bloginfo( 'url' ) ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/lotusdeveloper.png" alt="طراحی وب سایت" title="طراحی وب سایت" data-toggle="tooltip" data-placement="top"></a>
			</div>
		</footer>
	<?php 
	// wp_footer(); به اخرین خط از ساختار دیداری منتقل شد
	 ?>
	</main>
		
	<?php wp_footer(); ?>
	<script>
	$(function () {
		$('[data-toggle="tooltip"]').tooltip()
	})
    </script>
	
</body>
</html>